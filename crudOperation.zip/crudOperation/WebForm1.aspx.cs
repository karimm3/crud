﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace crudOperation
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            /*GridView1.Visible = false;
*/

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DateTime currentTime = DateTime.Now;
            // Retrieve user inputs
            string name = TextBox1.Text;
            string contact = TextBox2.Text;
            string email = TextBox3.Text;
            string specification = TextBox4.Text;
            string address = TextBox5.Text;

            string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);

            int i = 1;

          

      
                FileUpload1.SaveAs(Server.MapPath("resume\\" + fileName));
            
         



                // Perform database insert operation
                string connectionString = "Data Source=DESKTOP-OEMHJ6H;Initial Catalog=cruds;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO tables (Name, Contact, Email, Specification, Address, resume , date, updateTime) VALUES (@Name, @Contact, @Email, @Specification, @Address ,@resume ,'" + currentTime + "','" + null + "' )";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@Contact", contact);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@Specification", specification);
                        command.Parameters.AddWithValue("@Address", address);
                        command.Parameters.AddWithValue("@resume", fileName);

                        command.ExecuteNonQuery();
                        connection.Close();
                    }
                }


                 TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            


            // Clear form fields after insertion
           

            string script = "alert('Data inserted successfully.');";
            ScriptManager.RegisterStartupScript(this, GetType(), "InsertSuccessScript", script, true);


            GridView1.Visible = true;
            GridView1.DataBind();

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}