﻿namespace crudOperation
{
    internal class Date
    {
    }
}