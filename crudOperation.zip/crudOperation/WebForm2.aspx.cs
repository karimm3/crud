﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace crudOperation
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DateTime currentTime = DateTime.Now;

            string userId = Request.QueryString["id"];
            string updatedName = TextBox1.Text;
            string updatedContact = TextBox2.Text;
            string updatedEmail = TextBox3.Text;
            string updatedSpecification = TextBox4.Text;
            string updatedAddress = TextBox5.Text;

            string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);

         

          


                FileUpload1.SaveAs(Server.MapPath("resume\\" + fileName));
            
         


           



                // Perform database update operation
                string connectionString = "Data Source=DESKTOP-OEMHJ6H;Initial Catalog=cruds;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE tables SET name = @UpdatedName, contact = @UpdatedContact, Email = @UpdatedEmail, Specification = @UpdatedSpecification, " +
                        "Address = @UpdatedAddress , resume=@resume,updateTime =@UpdateTime  WHERE id = @UserID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UpdatedName", updatedName);
                        command.Parameters.AddWithValue("@UpdatedContact", updatedContact);
                        command.Parameters.AddWithValue("@UpdatedEmail", updatedEmail);
                        command.Parameters.AddWithValue("@UpdatedSpecification", updatedSpecification);
                        command.Parameters.AddWithValue("@UpdatedAddress", updatedAddress);
                        command.Parameters.AddWithValue("@resume", fileName);
                        command.Parameters.AddWithValue("@UpdateTime", currentTime);
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.ExecuteNonQuery();
                        connection.Close();

                        string script = "alert('Data inserted successfully.');";
                        ScriptManager.RegisterStartupScript(this, GetType(), "InsertSuccessScript", script, true);

                        Response.Redirect("WebForm1.aspx");
                    
                }

            }
        }
    }
}